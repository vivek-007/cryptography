package com.cms.main;

import java.sql.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.bean.*;

public class Driver {

	/**
	 * @param args
	 */
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User u1 = new User("XYZ");
		User u2 = new User("XYZ1");
		User u3 = new User("XYZ2");
		User u4 = new User("XYZ3");
		
		Qualification bcom = new Qualification("B.Com");
		Qualification ba = new Qualification("B.A.");
		Qualification be = new Qualification("B.E.");
		Qualification btech = new Qualification("B.Tech");
		
		Profile p1 = new Profile("school1","college1");
		Profile p2= new Profile("school2","college2");
		Profile p3 = new Profile("school3","college3");
		Profile p4 = new Profile("school4","college4");
		Profile p5 = new Profile("school5","college5");
		Profile p6 = new Profile("school6","college6");
		Profile p7 = new Profile("school7","college7");
		Profile p8 = new Profile("school8","college8");
		Profile p9 = new Profile("school9","college9");
		Profile p10 = new Profile("school0","college10");
		
		p1.addQualification(bcom);
		p2.addQualification(bcom);
		p3.addQualification(be);
		p4.addQualification(ba);
		p5.addQualification(ba);
		p6.addQualification(btech);
		p7.addQualification(bcom);
		p8.addQualification(ba);
		p9.addQualification(bcom);
		
		
		Contact c1 = new Contact("Vivek1", "Kumar", "vivek.kumar26@live.com", Date.valueOf("2017-01-01"), new Address("Vasco", "India"));
		Contact c2 = new Contact("Kartik2", "Malik", "kartik_malik@gmail.com", Date.valueOf("2017-02-02"), new Address("Porvorim", "India"));
		Contact c3 = new Contact("Aaron3", "Colaco", "aaron@gmail.com", Date.valueOf("2017-03-01"), new Address("Loutilim", "India"));
		Contact c4 = new Contact("Vivek4", "Kumar", "vivek.kumar26@live.com", Date.valueOf("2017-01-01"), new Address("Vasco", "India"));
		Contact c5 = new Contact("Kartik5", "Malik", "kartik_malik@gmail.com", Date.valueOf("2017-02-02"), new Address("Porvorim", "India"));
		Contact c6 = new Contact("Aaron6", "Colaco", "aaron@gmail.com", Date.valueOf("2017-03-01"), new Address("Loutilim", "India"));
		Contact c7 = new Contact("Vivek7", "Kumar", "vivek.kumar26@live.com", Date.valueOf("2017-01-01"), new Address("Vasco", "India"));
		Contact c8 = new Contact("Kartik8", "Malik", "kartik_malik@gmail.com", Date.valueOf("2017-02-02"), new Address("Porvorim", "India"));
		Contact c9 = new Contact("Aaron9", "Colaco", "aaron@gmail.com", Date.valueOf("2017-03-01"), new Address("Loutilim", "India"));
		
		c1.addProfile(new Profile("Kendriya Vidyalaya", "PCCE"));
		c2.addProfile(new Profile("School", "College"));
		c3.addProfile(new Profile("School", "College"));
		c4.addProfile(new Profile("School", "College"));
		c5.addProfile(new Profile("School", "College"));
		c6.addProfile(new Profile("School", "College"));
		c7.addProfile(new Profile("School", "College"));
		c8.addProfile(new Profile("School", "College"));
		c9.addProfile(new Profile("School", "College"));
		
		u1.addContact(c1);
		u1.addContact(c2);
		u1.addContact(c3);
		
		u2.getContacts().add(c4);
		c4.setOwner(u2);
		
		u3.getContacts().add(c5);
		u3.getContacts().add(c6);
		u3.getContacts().add(c7);
		u3.getContacts().add(c8);
		c5.setOwner(u3);
		c6.setOwner(u3);
		c7.setOwner(u3);
		c8.setOwner(u3);
		
		u4.getContacts().add(c9);
		c9.setOwner(u4);
		// c1.setContactID(100); c2.setContactID(200); c3.setContactID(300);
		
		Configuration cfg = new Configuration().configure();
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		session.save(u1);
		/*for(Contact c : u1.getContacts()) {
			session.save(c);
		}*/
		
		session.save(u2);
		/*for(Contact c : u2.getContacts()) {
			session.save(c);
		}*/
		
		session.save(u3);
		/*for(Contact c : u3.getContacts()) {
			session.save(c); 
		}*/
		
		session.save(u4);
		/*for(Contact c : u4.getContacts()) {
			session.save(c);
		}*/
		
		transaction.commit(); // triggers are executed at this point.
		
		session.clear();
		
		Query query = session.createQuery("from User"); // select * from tbl_users
		List<User> users = query.list();
		for(User u : users) {
			System.out.println(u.getUsername());
			for(Contact c : u.getContacts()) {
				System.out.println(c.getEmail());
			}
		}
		
		
		User retrivedUser;
		retrivedUser = (User) session.get(User.class, new Integer(1));
		/*System.out.println(retrivedUser.getUserId());
		System.out.println(retrivedUser.getUsername());*/
		System.out.println(retrivedUser.getContacts().size());
		
		/*for(Contact c:retrivedUser.getContacts()){
			System.out.println(c.getEmail());
		}*/
		
		
		// c1.setLastName("kumar $$$");
		//transaction = session.beginTransaction();
		
		/* Automatic Dirty Checking - Changes made to objects in session's cache are
		 * automatically updated in DB if transaction is committed.  
		 */
		
		// cannot call persist() on detached objects.
		// session.persist(c1); // session.update(c2);
		//transaction.commit();
		
		// session.clear(); // now SQL query is used to retireve; Cache is cleared.
		// session.delete(); // Executes SQL delete 
		
		/*Contact retrievedContact = (Contact) session.get(Contact.class, new Integer(1));
		System.out.println(retrievedContact);
		
		c1.setLastName("kumar $$$");
		transaction = session.beginTransaction();
		session.merge(c1); // merges retrievedContact & c1.
		transaction.commit();
		
		// session.evict(c2); // removes c2 from cache.
		session.clear(); // clears sesion's cache.
*/		session.close();
		sessionFactory.close();
	}

}
