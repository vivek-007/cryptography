package com.cms.bean;

import java.util.HashSet;
import java.util.Set;

public class User {
	private int userId;
	private String username;
	private Set<Contact> contacts = new HashSet<Contact>();
	
	
	public User() {
		super();
	}
		
	public User(String username) {
		super();
		this.username = username;
	}

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Set<Contact> getContacts() {
		return contacts;
	}
	public void setContacts(Set<Contact> contacts) {
		this.contacts = contacts;
	}
	
	public void addContact(Contact contact) {
		getContacts().add(contact);
		contact.setOwner(this);
	}
	
	
}
