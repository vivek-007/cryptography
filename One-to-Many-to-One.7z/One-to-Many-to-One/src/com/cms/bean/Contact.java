
package com.cms.bean;
import java.sql.Date;

public class Contact {
	
	private int contactID;
	private String firstName, lastName;
	private String email;
	private Date dateOfBirth;
	private Address address;
	private User owner;
	private Profile profile;
	
	// Constructors
	// Default constructor is a must for Hibernate projects 
	public Contact() {
		super();
	}
	
	public Contact(String firstName, String lastName,
			String email, Date dateOfBirth, Address address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
	}
	
	
	// Getters and Setters 
	public int getContactID() {
		return contactID;
	}
	public void setContactID(int contactID) {
		this.contactID = contactID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}
	

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}
	
	public void addProfile(Profile profile){
		setProfile(profile);
		profile.setContact(this);
		
	}

	@Override
	public String toString() {
		return "Contact [address=" + address + ", contactID=" + contactID
				+ ", dateOfBirth=" + dateOfBirth + ", email=" + email
				+ ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}
	
	
}
