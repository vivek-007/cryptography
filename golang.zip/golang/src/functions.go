package main

import(
	"fmt"
	"math"
)

var global int = 10

/*
	The ending of if statement and else block should be on same line. 
*/

// Function closures
func getSequence() func() int {
	i := 0
	return func() int {
		i = i + 1
		return i
	}
}

// Methods = Special types of functions

// define a circle
type Circle struct {
	x, y, radius float64
}

// define a method for Circle
func (circle Circle) area() float64 {
	return math.Pi * circle.radius * circle.radius
}

func main() {

	var a, b int = 7, 5
	var result int = max(a, b)
	fmt.Println("Max of ", a, "and ", b, "is ", result)

	x,y := "Vivek", "Kumar"
	m,n := swap(x, y)
	fmt.Println("Swapping values = ", m, n)

	swap_Reference(&x, &y)
	fmt.Println("Swapping values by swap_Reference = ", x, y)

	// functions as values
	getSquareRoot := func(x float64) float64 {
		return math.Sqrt(x)
	}
	fmt.Println("Sqaure root = ",getSquareRoot(9))

	// Function closures
	/* nextNumber is now a function with i as 0 */
   	nextNumber := getSequence()
   	fmt.Println(nextNumber())
   	fmt.Println(nextNumber())
   	fmt.Println(nextNumber())

   	// Methods = Special types of functions
   	circle := Circle{x:0, y:0, radius:5}
   	fmt.Println("Area of circle with radius ", circle.radius, "is ", circle.area())

   	// Scope rules
   	var global int = 20
   	fmt.Println(global)
}

// Call by value
func max(num1, num2 int) int {
	var result int
	if (num1 > num2) {
		result = num1
	} else {
		result = num2
	}
	return result
}

// Function returning multiple values
func swap(str1, str2 string) (string, string) {
	return str2, str1
}

// Function returning multiple values
func swap_Reference(str1 *string, str2 *string) {
	var temp string
	temp = *str1
	*str1 = *str2
	*str2 = temp
}