package main

import "fmt"

func main() {

	// Static type declaration
	var i, d int
	var x float64 = 93.57
	i = 97
	d = 42
	fmt.Println("Hello World!", i, d)
	fmt.Printf("x is of type %T\n", x)

	// Dynamic type declaration / Type Inference
	y := 420000.89
	fmt.Println(y)
	fmt.Printf("y is of type %T\n", y)

	// Mixed variable declaration
	var a, b, c = 3, 4, "foo"
	fmt.Println("Value of a = ", a)
   	fmt.Println("Value of b = ", b)
   	fmt.Println("Value of c = ", c)
   	fmt.Printf("a is of type %T\n", a)
   	fmt.Printf("b is of type %T\n", b)
   	fmt.Printf("c is of type %T\n", c)

   	// The const Keyword
   	const LENGTH int = 10
   	const WIDTH int = 5
   	var area int 
   	area = LENGTH * WIDTH
   	fmt.Println("Length = ", LENGTH, ";Width = ", WIDTH, ";Area = ", area)
}

/* 
	Variables should be declared and used.
	Constants should be defined in CAPTIALS.
*/