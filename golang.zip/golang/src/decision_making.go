package main 

/*
	Channels

	Channels are a typed conduit through which you can send and receive values with the channel operator, <-.

	ch <- v    // Send v to channel ch.
	v := <-ch  // Receive from ch, and
           // assign value to v.

	(The data flows in the direction of the arrow. )
*/

import (
	"fmt"
)

func main() {
	var grade string = ""
	var marks int = 90

	switch marks {
		case 90: grade = "A"
		case 80: grade = "B"
		case 50,60,70: grade = "C"
		default: grade = "D"
	}

	switch {
		case grade == "A": fmt.Println("Excellent")
		default: fmt.Println("Default is executed")
	}

	fmt.Println("Your grade is ", grade)

	// Type Switch
	var x interface{}
     
   	switch i := x.(type) {
      	case nil:	  
         	fmt.Printf("type of x :%T\n",i)                
      	case int:	  
       	    fmt.Printf("x is int\n")                       
      	case float64:
         	fmt.Printf("x is float64\n")           
      	case func(int) float64:
         	fmt.Printf("x is func(int)\n")                      
      	case bool, string:
         	fmt.Printf("x is bool or string\n")       
      	default:
         	fmt.Printf("don't know the type\n")     
   }

   // Select Statement - Similar to Switch 
   // The type for a case must be the a communication channel operation.

   var c1, c2, c3 chan int
   var i1, i2 int
   select {
      case i1 = <-c1:
         fmt.Printf("received ", i1, " from c1\n")
      case c2 <- i2:
         fmt.Printf("sent ", i2, " to c2\n")
      case i3, ok := (<-c3):  // same as: i3, ok := <-c3
         if ok {
            fmt.Printf("received ", i3, " from c3\n")
         } else {
            fmt.Printf("c3 is closed\n")
         }
      default:
         fmt.Printf("no communication\n")
   }

}