// Syntax - var variable_name [SIZE] variable_type
package main

import(
	"fmt"
)

func main() {

	var balance [5] float32 = [5]float32{1000.0, 2.0, 3.4, 7.0, 50.0}
	balance[0] = 1500.00

	var arrays = []float32{1000.0, 2.0, 3.4, 7.0, 50.0}
	arrays[1] = 2000.00

	fmt.Println(balance)
	fmt.Println(arrays)
}

