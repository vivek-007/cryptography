package main

import (
	"fmt"
)

func main() {
	sum := 0
	for i := 0; i < 10; i++ {
		sum += i;
	}
	fmt.Println(sum)

	//  For continued - The init and post statement are optional.

	cnt := 1
	for ; cnt < 1000; {
		cnt += cnt;
	}
	fmt.Println(cnt)

	// For is Go's "while" ; At that point you can drop the semicolons: C's while is spelled for in Go.

	cnt = 1;
	for cnt < 1000 {
		cnt += cnt;
	}
	fmt.Println(cnt)

	s := ""
	for ; s != "aaaaa";  {
    	fmt.Println("Value of s:", s)
    	s = s + "a"
	}

	//multiple initialization; a consolidated bool expression with && and ||; multiple ‘incrementation’
    for i, j, s := 0, 5, "a"; i < 3 && j < 100 && s != "aaaaa"; i, j, s = i+1, j+1, s + "a"  {
        fmt.Println("Value of i, j, s:", i, j, s)
    }

    i := 0
    for { //since there are no checks, this is an infinite loop
        if i >= 3 { break } //break out of this for loop when this condition is met
        fmt.Println("Value of i is:", i)
        i++;
    }
    fmt.Println("A statement just after for loop.")

    /* 
    	range keyword
		The range keyword allows you to iterate over items of a list like an array or a map. 
		For understanding it, you could translate the range keyword to for each index of. 
		When used with arrays and slices, it returns the integer index of the item. When used with maps, it returns the key of the next key-value pair. 
		It works with returning either one value or two. If only one, it is the index of the item, and if it is two then it is the index and the corresponding value.
    */

	//on an array, range returns the index
	a := [...]string{"a", "b", "c", "d"}
	for i := range a {
		fmt.Println(i)
	}

	//on a map, range returns the key 
	capitals := map[string] string {"France":"Paris", "Italy":"Rome", "Japan":"Tokyo" }
    for key := range capitals {
        fmt.Println("Map item: Capital of", key, "is", capitals[key])
    }

    //range can also return two items, the index/key and the corresponding value 
    for key2, val := range capitals {
        fmt.Println("Map item: Capital of", key2, "is", val)
    }

    for _, val := range capitals {
    	fmt.Println("Test -----------> ", val)
    }
}