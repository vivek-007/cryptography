package com.cms.main;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.bean.Contact;

public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Contact c1 = new Contact("Vivek", "Kumar", "vivek.kumar26@live.com", Date.valueOf("2017-01-01"));
		Contact c2 = new Contact("Kartik", "Malik", "kartik_malik@gmail.com", Date.valueOf("2017-02-02"));
		Contact c3 = new Contact("Aaron", "Colaco", "aaron@gmail.com", Date.valueOf("2017-03-01"));
		
		// c1.setContactID(100); c2.setContactID(200); c3.setContactID(300);
		
		Configuration cfg = new Configuration().configure();
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(c1); session.save(c2); session.save(c3);
		
		transaction.commit(); // triggers are executed at this point.
		session.close();
		sessionFactory.close();
	}

}
