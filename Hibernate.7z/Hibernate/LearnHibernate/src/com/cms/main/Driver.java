package com.cms.main;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.bean.Address;
import com.cms.bean.Contact;
import com.cms.bean.*;

public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Contact c1 = new Contact("Vivek", "Kumar", "vivek.kumar26@live.com", Date.valueOf("2017-01-01"), new Address("Vasco", "India"));
		Contact c2 = new Contact("Kartik", "Malik", "kartik_malik@gmail.com", Date.valueOf("2017-02-02"), new Address("Porvorim", "India"));
		Contact c3 = new Contact("Aaron", "Colaco", "aaron@gmail.com", Date.valueOf("2017-03-01"), new Address("Loutilim", "India"));
		
		// c1.setContactID(100); c2.setContactID(200); c3.setContactID(300);
		
		Configuration cfg = new Configuration().configure();
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.persist(c1); session.saveOrUpdate(c2); session.save(c3);
		
		transaction.commit(); // triggers are executed at this point.
		
		session.clear();
		
		// c1.setLastName("kumar $$$");
		//transaction = session.beginTransaction();
		
		/* Automatic Dirty Checking - Changes made to objects in session's cache are
		 * automatically updated in DB if transaction is committed.  
		 */
		
		// cannot call persist() on detached objects.
		// session.persist(c1); // session.update(c2);
		//transaction.commit();
		
		// session.clear(); // now SQL query is used to retireve; Cache is cleared.
		// session.delete(); // Executes SQL delete 
		
		Contact retrievedContact = (Contact) session.get(Contact.class, new Integer(1));
		System.out.println(retrievedContact);
		
		c1.setLastName("kumar $$$");
		transaction = session.beginTransaction();
		session.merge(c1); // merges retrievedContact & c1.
		transaction.commit();
		
		// session.evict(c2); // removes c2 from cache.
		session.clear(); // clears sesion's cache.
		session.close();
		sessionFactory.close();
	}

}
